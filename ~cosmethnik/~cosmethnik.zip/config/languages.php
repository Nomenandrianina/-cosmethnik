<?php
return [
    'fr' => [
        'display' => 'Français',
        'flag-icon' => 'fr'
    ],
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ]
    // ,
    // 'vi' => [
    //     'display' => 'Tiếng việt',
    //     'flag-icon' => 'vn'
    // ],
    // 'ja' => [
    //     'display' => 'Japanese',
    //     'flag-icon' => 'jp'
    // ]
];
