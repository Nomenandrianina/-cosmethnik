<?php

return array (
  'singular' => 'Unité',
  'plural' => 'Unités',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
