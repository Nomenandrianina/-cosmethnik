<?php

return array (
  'singular' => 'Materiaux',
  'plural' => 'Materiaux',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
