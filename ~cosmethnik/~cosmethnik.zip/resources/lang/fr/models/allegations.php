<?php

return array (
  'singular' => 'Allégation',
  'plural' => 'Allégations',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
