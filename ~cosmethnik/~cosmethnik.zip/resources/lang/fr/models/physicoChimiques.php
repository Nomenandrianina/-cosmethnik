<?php

return array (
  'singular' => 'Physico-chimique',
  'plural' => 'Physico-chimiques',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'unite' => 'Unité',
),
);
