<?php

return array (
  'singular' => 'Précaution d\'emploi',
  'plural' => 'Précautions d\'emploi',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
