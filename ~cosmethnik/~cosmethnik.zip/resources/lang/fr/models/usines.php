<?php

return array (
  'singular' => 'Usine',
  'plural' => 'Usines',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
