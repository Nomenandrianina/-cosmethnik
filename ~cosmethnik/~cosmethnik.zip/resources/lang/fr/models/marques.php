<?php

return array (
  'singular' => 'Marque',
  'plural' => 'Marques',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'decription' => 'Description',
  ),
);
