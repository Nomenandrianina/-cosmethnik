<?php

return array (
  'singular' => 'Famille',
  'plural' => 'Familles',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'parent_id' => 'Parent',
    'model_type' => 'Type Modèle',
    'model_id' => 'Id Modèle'
  ),
);
