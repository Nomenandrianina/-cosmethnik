<?php

return array (
  'singular' => 'Activité',
  'plural' => 'Activités',
  'fields' =>
  array (
    'id' => 'Id',
    'model_type' => 'Modèle type',
    'model_id' => 'Modèle id',
    'action' => 'Actions',
    'user_id' => 'Utilisateur',
  ),
);
