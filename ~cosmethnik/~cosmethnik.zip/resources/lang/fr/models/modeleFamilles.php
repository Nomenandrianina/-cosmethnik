<?php

return array (
  'singular' => 'Modèle famille',
  'plural' => 'Modèles familles',
  'fields' =>
  array (
    'id' => 'Id',
    'model_type' => 'Modèle type',
    'model_id' => 'Modèle id',
    'famille_id' => 'Familles',
  ),
);
