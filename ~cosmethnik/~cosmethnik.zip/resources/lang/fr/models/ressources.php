<?php

return array (
  'singular' => 'Ressource',
  'plural' => 'Ressources',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'etape' => 'Etape',
    'type_parametre' => 'Type de paramètre',
    'parametre' => 'Paramètre',
    'valeur' => 'Valeur',
    'unite' => 'Unité',
  ),
);
