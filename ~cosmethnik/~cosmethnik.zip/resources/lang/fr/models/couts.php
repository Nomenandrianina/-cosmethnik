<?php

return array (
  'singular' => 'Cout',
  'plural' => 'Couts',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'valeur' => 'Valeur',
    'unite' => 'Unité',
    'valeur1' => 'Valeur n-1',
    'valeur2' => 'Valeur n+1',
    'euv' => '€/UV',
    'manuel' => 'Manuel'
  ),
);
