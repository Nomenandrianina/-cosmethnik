<?php

return array (
  'singular' => 'Allergène',
  'plural' => 'Allergènes',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'description' => 'Description',
    'libelle_legale' => 'Libellé légal',
    'type' => 'Type',
    'code_allergene' => 'Code allèrgene',
    'seuil_reglementaire' => 'Seuil règlementaire',
    'allergene_enfant' => 'Allergène enfant',
  ),
);
