<?php

return array (
  'singular' => 'Etat produit',
  'plural' => 'Etat produits',
  'fields' =>
  array (
    'id' => 'Id',
    'designation' => 'Désignation',
  ),
);
