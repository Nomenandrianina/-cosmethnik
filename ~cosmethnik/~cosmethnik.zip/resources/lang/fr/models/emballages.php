<?php

return array (
  'singular' => 'Emballage',
  'plural' => 'Emballages',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'titre' => 'Titre',
    'description' => 'Description',
    'unite' => 'Unité',
  ),
);
