<?php

return array (
  'singular' => 'Produit-semi-fini',
  'plural' => 'Produit-semi-finis',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'unite' => 'Unité',
    'libelle_commerciale'=> 'Libellé commerciale',
    'libelle_legale'=> 'Libellé legale',
    'description'=>'Description',
    'code_bcepg'=>'Code beCPG',
    'code_erp'=>'Code ERP',
    'usine_id'=>'Usine',
    'geographique_id'=>'Origine géographique',
    'etat_produit_id'=>'Etat du produit',
),
);
