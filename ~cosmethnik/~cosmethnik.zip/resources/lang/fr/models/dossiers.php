<?php

return array (
  'singular' => 'Dossiers',
  'plural' => 'Dossiers',
  'fields' =>
  array (
    'id' => 'Id',
    'sites_id' => 'Sites Id',
    'name' => 'Nom',
    'title' => 'Titre',
    'description' => 'Description',
  ),
);
