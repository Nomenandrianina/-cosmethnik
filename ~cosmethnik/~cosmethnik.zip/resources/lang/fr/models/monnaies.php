<?php

return array (
  'singular' => 'Monnaie',
  'plural' => 'Monnaies',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
