<?php

return array (
  'singular' => 'Ingédient',
  'plural' => 'Ingédients',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'origine_geographique' => 'Origine géographique',
    'pays_transformation' => 'Pays de transformation',
    'origine_biologique' => 'Orignie biologique',
  ),
);
