<?php

return array (
  'singular' => 'Cas d\'emploie',
  'plural' => 'Cas d\'emploies',
  'fields' =>
  array (
    'id' => 'Id',
    'model_type' => 'Modèle type',
    'model_id' => 'Modèle id',
  ),
);
