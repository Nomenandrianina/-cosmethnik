<?php

return array (
  'singular' => 'Pays',
  'plural' => 'Pays',
  'fields' =>
  array (
    'id' => 'Id',
    'name' => 'Nom',
  ),
);
