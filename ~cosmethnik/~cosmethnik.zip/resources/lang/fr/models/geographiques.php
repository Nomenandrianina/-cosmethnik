<?php

return array (
  'singular' => 'Origine géographique',
  'plural' => 'Origines géographique',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
