<?php

return array (
  'singular' => 'Filiale',
  'plural' => 'Filiales',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
