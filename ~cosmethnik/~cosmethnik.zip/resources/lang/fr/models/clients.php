<?php

return array (
  'singular' => 'Client',
  'plural' => 'Clients',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'titre' => 'Titre',
    'etat_client' => 'Etat client',
    'code_bcpg' => 'Code Cosmethnik',
    'code_erp' => 'Code ERP',
    'telephone' => 'Téléphone',
    'mail' => 'Mail',
    'fax' => 'Fax',
    'adress1' => 'Adresse 1',
    'adress2' => 'Adresse 2',
    'adress3' => 'Adress 3',
    'ville' => 'Ville',
    'code_postal' => 'Code Postal',
    'pays_id' => 'Pays'
  ),
);
