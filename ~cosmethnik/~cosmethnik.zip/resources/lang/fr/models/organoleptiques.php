<?php

return array (
  'singular' => 'Organoleptique',
  'plural' => 'Organoleptiques',
  'fields' =>
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
