<?php

return array (
  'singular' => 'Condition de conservation',
  'plural' => 'Conditions de conservation',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
