<?php

return array (
  'singular' => 'Commentaire',
  'plural' => 'Commentaires',
  'fields' =>
  array (
    'id' => 'Id',
    'description' => 'Description',
    'model_type' => 'Type Modèle',
    'model_id' => 'Id Modèle'
  ),
);
