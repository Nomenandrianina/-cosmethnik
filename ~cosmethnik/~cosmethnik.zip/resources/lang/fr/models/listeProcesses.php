<?php

return array (
  'singular' => 'Liste des process',
  'plural' => 'Liste des process',
  'fields' =>
  array (
    'id' => 'Id',
    'model_type' => 'Modèle type',
    'model_id' => 'Modèle id',
    'quantite' => 'Quantité',
    'cadence' => 'Cadence',
    'unite_cadence' => 'Unité de cadence',
    'produit_heure' => 'Produit/h',
    'taux_horaire' => 'Taux/h',
  ),
);
