<?php

return [

    'add_new'      => 'Ajouter',
    'cancel'       => 'Annuler',
    'save'         => 'Enregistrer',
    'edit'         => 'Modifier',
    'detail'       => 'Détail',
    'back'         => 'Retour',
    'action'       => 'Action',
    'id'           => 'Id',
    'created_at'   => 'Created At',
    'updated_at'   => 'Updated At',
    'deleted_at'   => 'Deleted At',
    'are_you_sure' => 'Etes-vous sûr?',
];
