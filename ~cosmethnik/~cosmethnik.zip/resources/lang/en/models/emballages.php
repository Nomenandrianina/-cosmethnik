<?php

return array (
  'singular' => 'Emballages',
  'plural' => 'Emballages',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'titre' => 'Titre',
    'description' => 'Description',
    'unite' => 'Unite',
  ),
);
