<?php

return array (
  'singular' => 'Activités',
  'plural' => 'Activités',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'action' => 'Action',
    'user_id' => 'User Id',
  ),
);
