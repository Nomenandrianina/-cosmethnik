<?php

return array (
  'singular' => 'Modele_materiaux',
  'plural' => 'Modele_materiauxes',
  'fields' => 
  array (
    'id' => 'Id',
    'modele_type' => 'Modele Type',
    'modele_id' => 'Modele Id',
    'poids' => 'Poids',
    'materiaux_id' => 'Materiaux Id',
  ),
);
