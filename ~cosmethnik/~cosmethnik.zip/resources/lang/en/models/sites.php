<?php

return array (
  'singular' => 'Sites',
  'plural' => 'Sites',
  'fields' => 
  array (
    'id' => 'Id',
    'user_id' => 'User Id',
    'type' => 'Type',
    'nom' => 'Nom',
  ),
);
