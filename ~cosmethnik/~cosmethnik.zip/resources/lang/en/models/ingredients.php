<?php

return array (
  'singular' => 'Ingredients',
  'plural' => 'Ingredients',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'origine_geographique' => 'Origine Geographique',
    'pays_transformation' => 'Pays Transformation',
    'origine_biologique' => 'Origine Biologique',
  ),
);
