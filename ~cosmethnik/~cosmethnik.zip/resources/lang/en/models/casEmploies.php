<?php

return array (
  'singular' => 'Cas_emploies',
  'plural' => 'Cas_emploies',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
  ),
);
