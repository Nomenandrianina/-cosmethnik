<?php

return array (
  'singular' => 'Modele_emballages',
  'plural' => 'Modele_emballages',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'emballage_id' => 'Emballage Id',
    'quantite' => 'Quantite',
    'unite' => 'Unite',
    'freinte' => 'Freinte',
    'maitre' => 'Maitre',
    'variantes' => 'Variantes',
    'description' => 'Description',
  ),
);
