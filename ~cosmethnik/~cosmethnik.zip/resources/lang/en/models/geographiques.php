<?php

return array (
  'singular' => 'Geographiques',
  'plural' => 'Geographiques',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
