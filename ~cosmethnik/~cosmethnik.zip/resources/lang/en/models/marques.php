<?php

return array (
  'singular' => 'Marques',
  'plural' => 'Marques',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
