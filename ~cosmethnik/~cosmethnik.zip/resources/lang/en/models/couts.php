<?php

return array (
  'singular' => 'Couts',
  'plural' => 'Couts',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'valeur' => 'Valeur',
    'unite' => 'Unite',
    'valeur1' => 'Valeur1',
    'valeur2' => 'Valeur2',
    'euv' => 'Euv',
    'manuel' => 'Manuel',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
  ),
);
