<?php

return array (
  'singular' => 'Unites',
  'plural' => 'Unites',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
