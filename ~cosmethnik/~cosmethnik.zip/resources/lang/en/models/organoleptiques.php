<?php

return array (
  'singular' => 'Organoleptiques',
  'plural' => 'Organoleptiques',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
