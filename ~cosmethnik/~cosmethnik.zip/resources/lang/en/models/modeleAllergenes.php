<?php

return array (
  'singular' => 'Modele_allergenes',
  'plural' => 'Modele_allergenes',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'quantite' => 'Quantite',
    'pres_volontaire' => 'Pres Volontaire',
    'pres_fortuite' => 'Pres Fortuite',
    'arbre_decision' => 'Arbre Decision',
    'source_pres_volontaire' => 'Source Pres Volontaire',
    'source_pres_fortuite' => 'Source Pres Fortuite',
    'allergene_id' => 'Allergene Id',
  ),
);
