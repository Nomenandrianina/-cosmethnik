<?php

return array (
  'singular' => 'Monnaies',
  'plural' => 'Monnaies',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
