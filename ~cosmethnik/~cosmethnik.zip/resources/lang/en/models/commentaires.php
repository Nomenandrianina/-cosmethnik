<?php

return array (
  'singular' => 'Commentaires',
  'plural' => 'Commentaires',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
  ),
);
