<?php

return array (
  'singular' => 'Condition_conservations',
  'plural' => 'Condition_conservations',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
