<?php

return array (
  'singular' => 'Precaution_emploi',
  'plural' => 'Precaution_emplois',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
