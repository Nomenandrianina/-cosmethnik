<?php

return array (
  'singular' => 'Filiales',
  'plural' => 'Filiales',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
