<?php

return array (
  'singular' => 'Materiaux',
  'plural' => 'Materiauxes',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
