<?php

return array (
  'singular' => 'Dossiers',
  'plural' => 'Dossiers',
  'fields' => 
  array (
    'id' => 'Id',
    'sites_id' => 'Sites Id',
    'name' => 'Name',
    'title' => 'Title',
    'description' => 'Description',
  ),
);
