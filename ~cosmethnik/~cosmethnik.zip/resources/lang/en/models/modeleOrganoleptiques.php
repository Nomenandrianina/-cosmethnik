<?php

return array (
  'singular' => 'Modele_organoleptiques',
  'plural' => 'Modele_organoleptiques',
  'fields' => 
  array (
    'id' => 'Id',
    'caractéristique' => 'Caractéristique',
    'valeur' => 'Valeur',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'organoleptique_id' => 'Organoleptique Id',
  ),
);
