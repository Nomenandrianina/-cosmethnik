<?php

return array (
  'singular' => 'Allergenes',
  'plural' => 'Allergenes',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'description' => 'Description',
    'libelle_legale' => 'Libelle Legale',
    'type' => 'Type',
    'code_allergene' => 'Code Allergene',
    'seuil_reglementaire' => 'Seuil Reglementaire',
    'allergene_enfant' => 'Allergene Enfant',
  ),
);
