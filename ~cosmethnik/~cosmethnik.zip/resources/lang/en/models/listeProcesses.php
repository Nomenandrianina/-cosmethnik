<?php

return array (
  'singular' => 'Liste_process',
  'plural' => 'Liste_processes',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'ressource_id' => 'Ressource Id',
    'quantite' => 'Quantite',
    'cadence' => 'Cadence',
    'unite_cadence' => 'Unite Cadence',
    'taux_horaire' => 'Taux Horaire',
    'produit_heure' => 'Produit Heure',
  ),
);
