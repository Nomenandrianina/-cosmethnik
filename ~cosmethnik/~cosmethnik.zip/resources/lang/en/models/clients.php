<?php

return array (
  'singular' => 'Clients',
  'plural' => 'Clients',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'titre' => 'Titre',
    'etat_client' => 'Etat Client',
    'code_bcpg' => 'Code Bcpg',
    'code_erp' => 'Code Erp',
    'telephone' => 'Telephone',
    'mail' => 'Mail',
    'fax' => 'Fax',
    'adress1' => 'Adress1',
    'adress2' => 'Adress2',
    'adress3' => 'Adress3',
    'ville' => 'Ville',
    'code_postal' => 'Code Postal',
    'pays_id' => 'Pays Id',
  ),
);
