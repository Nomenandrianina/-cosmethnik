<?php

return array (
  'singular' => 'Compositions',
  'plural' => 'Compositions',
  'fields' => 
  array (
    'id' => 'Id',
    'quantite' => 'Quantite',
    'unite' => 'Unite',
    'poids' => 'Poids',
    'rendement' => 'Rendement',
    'freinte' => 'Freinte',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
  ),
);
