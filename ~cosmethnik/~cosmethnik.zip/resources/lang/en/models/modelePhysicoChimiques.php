<?php

return array (
  'singular' => 'Modele_physico_chimique',
  'plural' => 'Modele_physico_chimiques',
  'fields' => 
  array (
    'id' => 'Id',
    'caracteristique' => 'Caracteristique',
    'valeur' => 'Valeur',
    'mini' => 'Mini',
    'maxi' => 'Maxi',
    'critere_texte' => 'Critere Texte',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'physico_chimique_id' => 'Physico Chimique Id',
  ),
);
