<?php

return array (
  'singular' => 'Etat_produits',
  'plural' => 'Etat_produits',
  'fields' => 
  array (
    'id' => 'Id',
    'designation' => 'Designation',
  ),
);
