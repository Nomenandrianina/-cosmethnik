<?php

return array (
  'singular' => 'Modele_familles',
  'plural' => 'Modele_familles',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'famille_id' => 'Famille Id',
  ),
);
