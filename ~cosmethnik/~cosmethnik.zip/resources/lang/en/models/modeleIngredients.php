<?php

return array (
  'singular' => 'Modele_ingredients',
  'plural' => 'Modele_ingredients',
  'fields' => 
  array (
    'id' => 'Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'quantite' => 'Quantite',
    'ogm' => 'Ogm',
    'ionisation' => 'Ionisation',
    'auxilliaire_technologie' => 'Auxilliaire Technologie',
    'support' => 'Support',
    'ingredient_id' => 'Ingredient Id',
  ),
);
