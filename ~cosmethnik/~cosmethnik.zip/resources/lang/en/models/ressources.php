<?php

return array (
  'singular' => 'Ressources',
  'plural' => 'Ressources',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'etape' => 'Etape',
    'type_parametre' => 'Type Parametre',
    'parametre' => 'Parametre',
    'valeur' => 'Valeur',
    'unite' => 'Unite',
  ),
);
