<?php

return array (
  'singular' => 'Usines',
  'plural' => 'Usines',
  'fields' => 
  array (
    'id' => 'Id',
    'description' => 'Description',
  ),
);
