<?php

return array (
  'singular' => 'Modele_allegations',
  'plural' => 'Modele_allegations',
  'fields' => 
  array (
    'id' => 'Id',
    'allegation' => 'Allegation',
    'revendique' => 'Revendique',
    'information' => 'Information',
    'date_certification' => 'Date Certification',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
    'allegation_id' => 'Allegation Id',
  ),
);
