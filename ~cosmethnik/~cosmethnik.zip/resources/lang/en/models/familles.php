<?php

return array (
  'singular' => 'Famille',
  'plural' => 'Familles',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'parent__id' => 'Parent  Id',
    'model_type' => 'Model Type',
    'model_id' => 'Model Id',
  ),
);
