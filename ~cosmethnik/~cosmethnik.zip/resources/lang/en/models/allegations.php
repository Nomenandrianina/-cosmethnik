<?php

return array (
  'singular' => 'Allegations',
  'plural' => 'Allegations',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
  ),
);
