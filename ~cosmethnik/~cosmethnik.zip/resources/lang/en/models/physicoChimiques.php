<?php

return array (
  'singular' => 'Physico_chimiques',
  'plural' => 'Physico_chimiques',
  'fields' => 
  array (
    'id' => 'Id',
    'nom' => 'Nom',
    'unite' => 'Unite',
  ),
);
